#ifndef UTILITIES_H					// avoid repeated expansion
#define UTILITIES_H
void gotoxy(int x, int y);         //For Setting the position of Cursor
#endif