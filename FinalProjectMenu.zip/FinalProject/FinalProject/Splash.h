#ifndef	SPLASH_H
#define SPLASH_H
void splashScreen();
#endif